<?php

include_once("view/dashboard/index.php");